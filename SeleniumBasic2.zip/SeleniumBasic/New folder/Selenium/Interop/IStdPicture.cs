﻿using System;
using System.Runtime.InteropServices;

namespace Interop {

    [Guid("7BF80981-BF32-101A-8BBB-00AA00300CAB"), ComImport]
    public interface IStdPicture { }

}
